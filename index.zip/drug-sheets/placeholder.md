This folder holds files shown on the drug-sheets.html page. Delete this placeholder once real files are added.
