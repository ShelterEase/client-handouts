This folder holds files shown on the sops.html page. Delete this placeholder once real files are added.
