This folder holds files shown on the templates.html page. Delete this placeholder once real files are added.
