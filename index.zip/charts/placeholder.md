This folder holds files shown on the charts.html page. Delete this placeholder once real files are added.
